var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["8a7be8eb-5617-4fb8-81be-f974c2cf7076","ffef83d4-8fa9-4778-8ec0-273d4c673f1b","f89f2ee0-0355-4325-9d04-c6eb590e6171","9ebaaeb1-a961-4723-8069-12ef3d0a62d0","0e72c4ce-2f76-4472-8ef9-9703390b8a00","3b6e642c-400c-43cf-9bf2-68b2e8ff0730","80e44237-823e-414f-aa92-197d18fda9ba","d42a1728-9fcf-4e29-acaf-01c265e9e936","06a26a38-329d-46b6-a55c-6df1afe73b41","28964160-02a2-404c-9ecd-8d6911cc27c2"],"propsByKey":{"8a7be8eb-5617-4fb8-81be-f974c2cf7076":{"name":"Lilly","sourceUrl":"assets/api/v1/animation-library/gamelab/xb8zpsiPZ5SI98yOhX1InKeDnBSCd57./category_faces/kidportrait_04.png","frameSize":{"x":267,"y":357},"frameCount":1,"looping":true,"frameDelay":2,"version":"xb8zpsiPZ5SI98yOhX1InKeDnBSCd57.","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":267,"y":357},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xb8zpsiPZ5SI98yOhX1InKeDnBSCd57./category_faces/kidportrait_04.png"},"ffef83d4-8fa9-4778-8ec0-273d4c673f1b":{"name":"kidportrait_0","sourceUrl":"assets/api/v1/animation-library/gamelab/JGw3x8mqIDdntLjBneM5sF1rRaODdxDs/category_faces/kidportrait_09.png","frameSize":{"x":298,"y":366},"frameCount":1,"looping":true,"frameDelay":2,"version":"JGw3x8mqIDdntLjBneM5sF1rRaODdxDs","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":298,"y":366},"rootRelativePath":"assets/api/v1/animation-library/gamelab/JGw3x8mqIDdntLjBneM5sF1rRaODdxDs/category_faces/kidportrait_09.png"},"f89f2ee0-0355-4325-9d04-c6eb590e6171":{"name":"gameplaywacky_06_1","sourceUrl":"assets/api/v1/animation-library/gamelab/QlASZ_b6ro5ayl24.MEPiWwjrdbFB3sB/category_germs/gameplaywacky_06.png","frameSize":{"x":399,"y":384},"frameCount":1,"looping":true,"frameDelay":2,"version":"QlASZ_b6ro5ayl24.MEPiWwjrdbFB3sB","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":399,"y":384},"rootRelativePath":"assets/api/v1/animation-library/gamelab/QlASZ_b6ro5ayl24.MEPiWwjrdbFB3sB/category_germs/gameplaywacky_06.png"},"9ebaaeb1-a961-4723-8069-12ef3d0a62d0":{"name":"gameplaywacky_10_1","sourceUrl":"assets/api/v1/animation-library/gamelab/kMWv_JmgF4a6ZBEKvp_RVVgM8sQh7vQJ/category_germs/gameplaywacky_10.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"kMWv_JmgF4a6ZBEKvp_RVVgM8sQh7vQJ","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/kMWv_JmgF4a6ZBEKvp_RVVgM8sQh7vQJ/category_germs/gameplaywacky_10.png"},"0e72c4ce-2f76-4472-8ef9-9703390b8a00":{"name":"gameplaywacky_08_1","sourceUrl":"assets/api/v1/animation-library/gamelab/pXgSZduHyTVqHeNb_Mp3Xgv2qKVpLPQk/category_germs/gameplaywacky_08.png","frameSize":{"x":399,"y":380},"frameCount":1,"looping":true,"frameDelay":2,"version":"pXgSZduHyTVqHeNb_Mp3Xgv2qKVpLPQk","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":399,"y":380},"rootRelativePath":"assets/api/v1/animation-library/gamelab/pXgSZduHyTVqHeNb_Mp3Xgv2qKVpLPQk/category_germs/gameplaywacky_08.png"},"3b6e642c-400c-43cf-9bf2-68b2e8ff0730":{"name":"wheat_grow_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Ij9scPpmn.VR8eYJh9j5ine6g8MexZyb/category_video_games/wheat_grow.png","frameSize":{"x":128,"y":128},"frameCount":4,"looping":true,"frameDelay":2,"version":"Ij9scPpmn.VR8eYJh9j5ine6g8MexZyb","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":256,"y":256},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Ij9scPpmn.VR8eYJh9j5ine6g8MexZyb/category_video_games/wheat_grow.png"},"80e44237-823e-414f-aa92-197d18fda9ba":{"name":"powerupYellow_bolt_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qmAPnfWrN7w3vAVqAt8dBkNe50ZUxu6h/category_video_games/powerupYellow_bolt.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"qmAPnfWrN7w3vAVqAt8dBkNe50ZUxu6h","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qmAPnfWrN7w3vAVqAt8dBkNe50ZUxu6h/category_video_games/powerupYellow_bolt.png"},"d42a1728-9fcf-4e29-acaf-01c265e9e936":{"name":"pupilportrait","sourceUrl":"assets/api/v1/animation-library/gamelab/bj5kzu_ux3FP2R.7jZ0Oi1FnHKlS7ePT/category_faces/pupilportrait_10.png","frameSize":{"x":282,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"bj5kzu_ux3FP2R.7jZ0Oi1FnHKlS7ePT","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":282,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bj5kzu_ux3FP2R.7jZ0Oi1FnHKlS7ePT/category_faces/pupilportrait_10.png"},"06a26a38-329d-46b6-a55c-6df1afe73b41":{"name":"gameplaywacky_03_1","sourceUrl":"assets/api/v1/animation-library/gamelab/dtwdmhu18R0XcS9DpMKYtymNRtdl4ChR/category_germs/gameplaywacky_03.png","frameSize":{"x":390,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"dtwdmhu18R0XcS9DpMKYtymNRtdl4ChR","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dtwdmhu18R0XcS9DpMKYtymNRtdl4ChR/category_germs/gameplaywacky_03.png"},"28964160-02a2-404c-9ecd-8d6911cc27c2":{"name":"virus02_04_1","sourceUrl":"assets/api/v1/animation-library/gamelab/BnjDVhiSCi1qxzxKHZpbeYSo.y5kz0tq/category_germs/virus02_04.png","frameSize":{"x":400,"y":396},"frameCount":1,"looping":true,"frameDelay":2,"version":"BnjDVhiSCi1qxzxKHZpbeYSo.y5kz0tq","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":396},"rootRelativePath":"assets/api/v1/animation-library/gamelab/BnjDVhiSCi1qxzxKHZpbeYSo.y5kz0tq/category_germs/virus02_04.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var wall1 = createSprite(250, 130, 300, 5);
wall1.shapeColor = "black";
var wall2 = createSprite(150, 260, 300, 5);
wall2.shapeColor = "black";
var pupilportrait = createSprite(20, 335, 15, 15);
pupilportrait.shapeColor = "yellow";

var ball1 = createSprite(90, 335, 10, 10);

var ball2 = createSprite(125, 335, 10, 10);

var ball3 = createSprite(155, 335, 10, 10);

var ball4 = createSprite(185, 335, 10, 10);

var ball5 = createSprite(215, 335, 10, 10);

var ball6 = createSprite(245, 335, 10, 10);



var line1 = createSprite(130, 200, 10, 7);

var line2 = createSprite(200, 200, 10, 7);

var line3 = createSprite(275, 200, 10, 7);

line1.shapeColor = "red";

line2.shapeColor = "red";

line3.shapeColor = "red";


var ball7 = createSprite(200, 100, 10, 10);
var ball8 = createSprite(250 ,100, 10 , 10);
var ball9 = createSprite(150 ,100 , 10 , 10);
var ball10= createSprite(300 , 100 , 10 , 10);


ball7.shapeColor = "white";
ball8.shapeColor = "white";
ball9.shapeColor = "white";
ball10.shapeColor = "white";

var Lilly = createSprite(360, 75, 20, 20);
Lilly.shapeColor = "indigo";


var score = 0;


var gameState = "play";

velocity();

function draw() {
  background("Royalblue");
  bounce();
  if(keyDown("left")){
   pupilportrait.x = pupilportrait.x-3;
   gameState = "play";
  }
  if(keyDown("right")){
    pupilportrait.x = pupilportrait.x+3;
    gameState = "play";
  }
  if(keyDown("up")){
    pupilportrait.y = pupilportrait.y-3;
    gameState = "play";
  }
  if(keyDown("down")){
    pupilportrait.y = pupilportrait.y+3;
    gameState = "play";
  }
  
  textSize(18);
  stroke("white");
  text("DEATHS: "+score, 30, 30);
  
  pupilportrait.setAnimation("pupilportrait");
 pupilportrait.scale = 0.10; 
 
  Lilly.setAnimation("Lilly");
  Lilly.scale = 0.10;
  
  ball7.setAnimation("gameplaywacky_03_1");
  ball7.scale = 0.10;
  
  ball8.setAnimation("gameplaywacky_03_1");
  ball8.scale = 0.10;
  
  ball9.setAnimation("gameplaywacky_03_1");
  ball9.scale = 0.10;
  
  ball10.setAnimation("gameplaywacky_03_1");
  ball10.scale = 0.10;
  
  line1.setAnimation("gameplaywacky_06_1");
  line1.scale = 0.10;
  
  line2.setAnimation("gameplaywacky_10_1");
  line2.scale = 0.10;
  
  line3.setAnimation("gameplaywacky_06_1");
  line3.scale = 0.10;
  
  
  
  
  
  
  
  
  
  
  
  
  
  if(pupilportrait.collide(ball1)||pupilportrait.collide(ball2)||pupilportrait.collide(ball3)||pupilportrait.collide(ball4)
     ||pupilportrait.collide(ball5)||pupilportrait.collide(ball6)||pupilportrait.collide(ball7)||pupilportrait.collide(ball8)||
    pupilportrait .collide(ball9)||pupilportrait.collide(ball10)||pupilportrait.collide(line1)||pupilportrait.collide(line2)||pupilportrait.collide(line3)){
    reset();
    score = score+1;
  }
  
  if(pupilportrait.collide(Lilly)){
    
    gameState = "over";
    
    text("Hello Friend!",200, 200);
    
    pupilportrait.velocityX = 2;
    
    pupilportrait.velocityY = 2;
    
    score = 0;
    
    text("press R to restart", 200, 220);
  }
  
  if(keyDown("R")&&gameState === "over"){
    
    reset();
  }
  
  drawSprites();
  
}
function reset(){
  pupilportrait.x = 20;
  pupilportrait.y = 335;
  pupilportrait.velocityX = 0;
  pupilportrait.velocityY = 0;
}


function velocity(){
  
  
  ball1.velocityY = 10;
  
  ball2.velocityY = -10;
  
  ball3.velocityY = 10;
  
  ball4.velocityY = -10;
  
  ball5.velocityY = 10;
  
  ball6.velocityY = -10;
  
  ball7.velocityY = -15;
  
  ball8.velocityY = 15;
  
  ball9.velocityY = 15;
  
  ball10 .velocityY = -15;
  
 
  line1.velocityY =5;
  
  line2.velocityY = -5;
  
  line3.velocityY = 5;
 }



function bounce(){
  createEdgeSprites();
  ball1.bounceOff(edges);
  
  ball2.bounceOff(edges);
  
  ball3.bounceOff(edges);
  
  ball4.bounceOff(edges);
  
  ball5.bounceOff(edges);
  
  ball6.bounceOff(edges);
  
  ball1.bounceOff(edges);
  
  ball2.bounceOff(edges);
  
  ball3.bounceOff(edges);
  
  ball4.bounceOff(edges);
  
  ball5.bounceOff(edges);
  
  ball6.bounceOff(edges);
  
  ball7.bounceOff(edges);
  
  ball8 .bounceOff(edges);
  
  ball9 .bounceOff(edges);
  
  ball10 .bounceOff(edges);
  
   pupilportrait.bounceOff(edges);
  
  
  ball1.bounceOff(wall2);
  
  ball2.bounceOff(wall2);
  
  ball3.bounceOff(wall2);
  
  ball4.bounceOff(wall2);
  
  ball5.bounceOff(wall2);
  
  ball6.bounceOff(wall2);
  
  
  line1.bounceOff(wall1);
  
  line1.bounceOff(wall2);
  line2.bounceOff(wall1);
  line2.bounceOff(wall2);
  line3.bounceOff(wall1);
  line3.bounceOff(wall2);
  line1.bounceOff(edges);
  line2.bounceOff(edges);
  line3.bounceOff(edges);
  
  ball7.bounceOff(wall1);
  
  ball8 .bounceOff(wall1);
  
  ball9.bounceOff(wall1);
  
  ball10 .bounceOff(wall1);
  
  
 
  
  pupilportrait.bounceOff(wall1);
  pupilportrait.bounceOff(wall2);
}
ball1.shapeColor = "red";

ball2.shapeColor = "red";

ball3.shapeColor = "red";

ball4.shapeColor = "red";

ball5.shapeColor = "red";

ball6.shapeColor = "red";

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
